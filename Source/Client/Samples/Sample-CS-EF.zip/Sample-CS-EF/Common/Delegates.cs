﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QuantumConcepts.CodeGenerator.Sample.Common
{
    /// <summary>A general purpose delegate which does not take a parameter.</summary>
    public delegate void ParameterlessDelegate();
}
