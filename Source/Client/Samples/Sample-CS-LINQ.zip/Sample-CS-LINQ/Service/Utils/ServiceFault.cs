using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace QuantumConcepts.CodeGenerator.Sample.Service.Utils
{
    [DataContract]
    public class ServiceFault
    {
    }
}
